<?php

namespace App\Http\Middleware;

class LevelDosenMiddleware extends LevelMiddleware
{   
    protected $level = '2';
}